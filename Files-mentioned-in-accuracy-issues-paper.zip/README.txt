Only the PM7(Aq) fully-optimized geometries are given.  These correspond to the last column in Table 1.  

Uncatalyzed retro-ene elimination of isochorismic acid to salicylic acid plus pyruvic acid.

Reactant: Isochorismic acid.mop
Products: Pyruvic acid plus salicylic acid.mop

Move pyruvic acid plus salicylic acid onto slope:
Pyruvic acid plus salicylic acid for slope.mop

Move isochorismic acid onto slope:
Isochorismic acid for slope.mop

Search for saddle point using geometries on slope:
Isochorismic_to_salicylic_plus_pyruvic_acid_saddle.mop

Refine transition state, characterise, and map IRC:
Isochorismic_to_salicylic_plus_pyruvic_acid_ts.mop

The figures shown on-line at HTTP://OpenMOPAC.net/ can be run using the files in this ZIP.

Testing was done using Netscape.  The graphics might not work on other browsers.

To edit Netscape so that it can run JSmol HTML files produced by MOPAC, see:  HTTP://OpenMOPAC.net/Manual/README_for_JSmol.html. 
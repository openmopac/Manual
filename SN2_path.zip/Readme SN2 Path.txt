How to use a reaction path to find a transition state for a reaction with one
well-defined coordinate.

This example is the reaction of F(-) with CH3-Br to form CH3-F plus Br(-)

Starting with the optimized geometry for CH3-Br + F(-), the F-C distance is steadily
reduced until a normal C-F bond is formed.  Data set:
SN2 path.mop

Inspection of the output file shows that the heat of formation went through a maximum
at a C-F distance of about 2.15 Angstroms.  The geometry at this point is then used
in a transition state refinement, characterization, and reaction profile generation.
Data set:
SN2_Path_Refinement.mop


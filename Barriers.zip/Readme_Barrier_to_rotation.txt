In this example, the C2-C3 bond in butane is rotated from the initial torsion equilibrium value of 180
degrees in steps of 5 degrees to zero degrees.  Data set:
Rotation_barrier.mop

On the way, two maxima are detected, one at about 240 degrees and one at exactly 0 or 360 degrees.

The transition state (barrier to rotation) at 240 degrees is optimized and characterised, data set:
Barrier_near_to_240_degrees.mop

The transition state at exactly zero degrees is narcissistic, so it only needs to be characterized,
data set:
Barrier_at_0_degrees.mop  
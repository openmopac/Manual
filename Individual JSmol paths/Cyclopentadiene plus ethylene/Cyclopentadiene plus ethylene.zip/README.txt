Two steps are used for finding the transition state; locate_TS.mop followed by Saddle_TS.mop

The first step uses LOCATE-TS to move the two reactant geometries near to each other.  The second step uses the Saddle calculation to locate the TS.

The transition state can also be found by using LOCATE-TS on its own.

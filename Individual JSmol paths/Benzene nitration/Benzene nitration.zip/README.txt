Nitration of benzene using sulfuric acid as a catalyst

Reaction:  Benzene + [NO2](+) +[HSO4](-) <=> Nitrobenzene + H2SO4 + H2O

Experimentally, this reaction is carried out in the liquid phase, but here the system is gas-phase. Trying to run the system in liquid phase was not successful.
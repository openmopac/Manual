In this example, the C2-C3 bond in butane is rotated from the initial torsion equilibrium value of 180
degrees in steps of 4 degrees to 536 degrees.  Data set:
Rotation_barrier.mop

On the way, three maxima are detected, two at about 120 nand -120 degrees and one at exactly 0 or 360 degrees.

The transition state (barrier to rotation) at 120 degrees is optimized and characterised, data set:
Barrier_near_to_120_degrees.mop

The transition state at exactly zero degrees is narcissistic, so it only needs to be characterized,
data set:
Barrier_at_0_degrees.mop  
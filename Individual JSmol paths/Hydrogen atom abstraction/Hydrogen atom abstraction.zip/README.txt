This reaction involves a hydrogen atom migrating from a large organic moiety to a methyl group to form a large organic radical and a methane molecule.

In the IRC, the reaction has a very sharp transition state, but in the DRC the transition state looks more conventional.
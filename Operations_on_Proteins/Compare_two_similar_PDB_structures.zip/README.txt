Two unmodified protein structures, 1AP9 and 1AT9, from the PDB, representing the same system, bacteriorhodopsin, are compared using MOPAC.

Jobs:

Run "ADD-H  Bacteriorhodopsin 1AP9.mop" This small file consists of two lines.  The first of these points to the input data set, 1AP9.pdb, defines the operation to be done, ADD-H, and requests, keyword HTML, the writing of files to allow a quick examination of the results using JSmol. The only entry on the second line is the title of the job.  This will be reproduced in the HTML file.

The output file, "ADD-H  Bacteriorhodopsin 1AP9.out" prints out the input keywords, with two extra keywords added, "START_RES=(7A 300)" and "CHAINS=(A)"  These keywords were generated using information in the 1AP9.ent file.  This is followed by four complete geometries; the first two are related to the geometry from the input data set, re-formatted to look like a MOPAC data set; the second two are the geometries after hydrogenation and re-sequencing, these are in MOPAC and in PDB format.

The ARC file, "ADD-H  Bacteriorhodopsin 1AP9.arc", will be used as an input geometry in the comparison calculation.

If the HTML file, ""ADD-H  Bacteriorhodopsin 1AP9.html", is opened using a browser (testing was done using Firefox), then the structure of 1AP9 can be examined.  The HTML file reads in the geometry is the newly-created file ""ADD-H  Bacteriorhodopsin 1AP9.pdb"


Run "ADD-H  Bacteriorhodopsin 1AT9.mop"  This gives similar results to the previous run.

Run "Compare PDB Bacteriorhodopsin 1AP9 and 1AT9.mop"  
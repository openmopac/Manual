For instructions on using BZ, see:

HTTP://OpenMOPAC.net/Manual/Program_BZ.html
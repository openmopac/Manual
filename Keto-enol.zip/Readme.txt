Keto - Ene-ol tautomerization

Starting geometries:
Keto.mop
Enol.mop

Move onto slope of activation barrier:
Keto_for_slope.mop

Then move enol onto slope:
Enol_for_slope.mop

Use both geometries on slope to get approximation to transition state:
Enol_on_slope_ts.mop

Refine is, characterize and generate IRC:
Keto_enol_ts.mop

Note:  The transition state is the highest point on the lowest energy path from
reactant to product (here keto to enol)  Going down the path from the 
transition state does not necessarily lead to the lowest energy conformations.
In this case, the hydroxyl ends up pointing away from the water in the keto form.

Other minima on the PES are:
keto_complex.mop
Keto_higher.mop






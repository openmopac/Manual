For instructions on installing JSmol for use with MOPAC, see:

HTTP://OpenMOPAC.net/Manual/README_for_JSmol.html
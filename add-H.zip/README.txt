To run these jobs, download the protein system from the Protein Data Bank, and run the appropriate <file>.mop 
using test_hydrogenation_one_system.cmd, as in:

test_hydrogenation_one_system.cmd "8GCH Add-H"

For a worked example, all the files for 8GCH are present. Run "8GCH Add-H.mop" using MOPAC, then
run the newly-created file "8GCH Add-H.arc" using MOPAC.   